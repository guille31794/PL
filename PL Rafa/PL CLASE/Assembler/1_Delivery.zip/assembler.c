int main()
{
    int a;
    return 0;
}