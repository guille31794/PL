

####################################################################
#   TRABAJO REALIZADO POR JUAN RUIZ BONALD,RAFAEL ROMAN AGUILAR #
###################################################################


from sly import Lexer,Parser

class PracLexer(Lexer):
    # Set of token names.   This is always required
    tokens = { NUMBER, ID, WHILE, IF, ELSE, RETURN, SCANF, PRINT,
               INT, PLUS, MINUS, TIMES, DIVIDE, ASSIGN,
               EQ, LT, LE, GT, GE, NE, AND, OR, NOT}


    literals = { '(', ')', '{', '}', ';' }

    # String containing ignored characters
    ignore = ' \t'

    # Regular expression rules for tokens
    PLUS    = r'\+'
    MINUS   = r'-'
    TIMES   = r'\*'
    DIVIDE  = r'/'
    EQ      = r'=='
    ASSIGN  = r'='
    LE      = r'<='
    LT      = r'<'
    GE      = r'>='
    GT      = r'>'
    NE      = r'!='
    AND     = r'&&'
    OR      = r'\|\|'
    NOT     = r'\!'

    @_(r'\d+')
    def NUMBER(self, t):
        t.value = int(t.value)
        return t

    # Identifiers and keywords
    ID = r'[a-zA-Z_][a-zA-Z0-9_]*'
    ID['if'] = IF
    ID['else'] = ELSE
    ID['while'] = WHILE
    ID['print'] = PRINT
    ID['return'] = RETURN
    ID['scanf'] = SCANF
    ID['int'] = INT

    ignore_comment = r'\#.*'

    # Line number tracking
    @_(r'\n+')
    def ignore_newline(self, t):
        self.lineno += t.value.count('\n')

    def error(self, t):
        print('Line %d: Bad character %r' % (self.lineno, t.value[0]))
        self.index += 1

global cabecera, inFunction, tablaVarLocal, pila, eax
inFunction = False
tablaVarLocal = {}
eax = False
cabecera = 4
pila = 0
        
class Nodo():
    def escribir(self):
        pass
        
class NodoFuncion(Nodo): #Nodo utilizado para las funciones
    global f_salida
    i = None
    def __init__(self, valor):
        self.i = valor
    def escribirPrincipio(self):
        f_salida.write(".text\n.globl " + self.i + "\n.type " + self.i + ", @function\n" + self.i + ":\n" )
        
        
class NodoInic(Nodo): #Nod activado cuando la función comienza
    global f_salida
    def __init__(self):
        self.names = { }
    def escribirPrologo(self):
        f_salida.write("    pushl %ebp\n    movl %esp, %ebp\n\n")
    def escribirFinal(self):
        f_salida.write("    movl %ebp, %esp\n    popl %ebp\n    ret")

        
class NodoVariables(Nodo): #Nodo activado para almacenar las variables 
    global f_salida, tablaVarLocal
    i = None
    j = None
    def __init__(self, nombre,valor):
        self.i = nombre
        self.j = valor
    def escribirInic(self):
        f_salida.write("    subl $4, %esp\n") #Funcion creada para reservar espacio
                                          #cada vez que detectamos una variabe
    def almacenarVariable(self):
        tablaVarLocal[self.i] = {self.j}

class NodoOperacionesArit(Nodo):
    global f_salida, tablaVarLocal, eax
    x = None
    y = None
    def __init__(self, valor1, valor2):
        self.x = valor1
        self.y = valor2
    def escribirSuma1(self): #LLamaremos a esta función cuando el primer elemento NO sea un entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        if self.x in tablaVarLocal: #Si x fuera local

            f_salida.write("    movl " + tablaVarLocal[self.x] + "(%ebp), %eax\n")
            if self.y in tablaVarLocal: #Si fuera una variable local
                f_salida.write("    addl " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
            else:   
                f_salida.write("    addl " + self.y + ", %eax\n")                    #Si y fuera una global

        else:   #Si x fuera global
            f_salida.write("    movl " + self.x + ", %eax\n")
            if self.y in tablaVarLocal: #Si y fuera una variable local
                f_salida.write("    addl " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
            else:                       #Si fuera una global
                f_salida.write("    addl " + self.y + "(%ebp), %eax\n")
        eax = True


    def escribirSuma2(self): #LLamaremos a esta función cuando el primer elemento sea un entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        f_salida.write("    movl $" + self.x + "(%ebp), %eax\n")
        if self.y in tablaVarLocal: #Si fuera una variable local
            f_salida.write("    addl " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
        else:                       #Si fuera una global
            if type(self.y) == int:
                f_salida.write("    addl $" + self.y + ", %eax\n")
            else: #Si y fuera una global
                f_salida.write("    addl " + self.y + ", %eax\n")
        eax = True
        
        
    def escribirResta1(self): #LLamaremos a esta función cuando el primer elemento NO sea un entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        if self.x in tablaVarLocal: #Si x fuera local

            f_salida.write("    movl " + tablaVarLocal[self.x] +"(%ebp), %eax\n")
            if self.y in tablaVarLocal: #Si fuera una variable local
                f_salida.write("    subl " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
            else:   
                f_salida.write("    subl " + self.y + ", %eax\n")                    #Si y fuera una global

        else:   #Si x fuera global
            f_salida.write("    movl " + self.x + ", %eax\n")
            if self.y in tablaVarLocal: #Si y fuera una variable local
                f_salida.write("    subl " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
            else:                       #Si fuera una global
                f_salida.write("    subl " + self.y + "(%ebp), %eax\n")
        eax = True


    def escribirResta2(self):#LLamaremos a esta función cuando el primer elemento sea un entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        f_salida.write("    movl $" + self.x + "(%ebp), %eax\n")
        if self.y in tablaVarLocal: #Si fuera una variable local
            f_salida.write("    subl " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
        else:                       #Si fuera una global
            if type(self.y) == int:
                f_salida.write("    subl $" + self.y + ", %eax\n")
            else:   #Si y fuera una global
                f_salida.write("    subl " + self.y + ", %eax\n")
        eax = True

    def escribirMulti1(self): #LLamaremos a esta función cuando el primer elemento sea un entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        if self.x in tablaVarLocal: #Si x fuera local

            f_salida.write("    movl " + tablaVarLocal[self.x] + "(%ebp), %eax\n")
            if self.y in tablaVarLocal: #Si fuera una variable local
                f_salida.write("    imull " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
            else:   
                f_salida.write("    imull " + self.y + ", %eax\n")                    #Si y fuera una global

        else:   #Si x fuera global
            f_salida.write("    movl " + self.x + ", %eax\n")
            if self.y in tablaVarLocal: #Si y fuera una variable local
                f_salida.write("    imull " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
            else:                       #Si fuera una global
                f_salida.write("    imull " + self.y + "(%ebp), %eax\n")
        eax = True


    def escribirMulti2(self): #LLamaremos a esta función cuando el primer elemento NO sea un entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        f_salida.write("    movl $" + self.x + "(%ebp), %eax\n")
        if self.y in tablaVarLocal: #Si fuera una variable local
            f_salida.write("    imull " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
        else:                       #Si fuera una global
            if type(self.y) == int:
                f_salida.write("    imull $" + self.y + ", %eax\n")
            else:   #Si y fuera una global
                f_salida.write("    imull " + self.y + ", %eax\n")
        eax = True

 
    def escribirDivi1(self): #LLamaremos a esta función cuando el primer elemento NO sea un entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        if self.x in tablaVarLocal:
            f_salida.write("    movl " + tablaVarLocal[self.x] + "(%ebp), %eax\n")
            f_salida.write("    cdq\n")
            if self.y in tablaVarLocal: #Si fuera una variable
                f_salida.write("    movl " + tablaVarLocal[self.y] + "(%ebp), %ecx\n")
                f_salida.write("    divl %ecx\n")
                f_salida.write("    movl %ecx, %eax\n")
            else:                       #Si fuera una global
                f_salida.write("    movl " + self.y + "(%ebp), %ecx\n")
                f_salida.write("    divl %ecx\n")
                f_salida.write("    movl %ecx, %eax\n")
        else:   #Si fuera un numero entero
            f_salida.write("    movl " + self.x + ", %eax\n")
            f_salida.write("    cdq\n")
            if self.y in tablaVarLocal: #Si fuera una variable
                f_salida.write("    movl " + tablaVarLocal[self.y] + "(%ebp), %ecx\n")
                f_salida.write("    divl %ecx\n")
                f_salida.write("    movl %ecx, %eax\n")
            else:                       #Si fuera una global
                f_salida.write("    movl " + self.y + "(%ebp), %ecx\n")
                f_salida.write("    divl %ecx\n")
                f_salida.write("    movl %ecx, %eax\n")
        eax = True

    def escribirDivi2(self):#LLamaremos a esta función cuando el primer elemento sea un entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        f_salida.write("    movl $" + self.x + "(%ebp), %eax\n")
        f_salida.write("    cdq\n")
        if self.y in tablaVarLocal: #Si fuera una variable
            f_salida.write("    imull " + tablaVarLocal[self.y] + "(%ebp), %eax\n")
            f_salida.write("    divl %ecx\n")
            f_salida.write("    movl %ecx, %eax\n")
                
        else:
            if type(self.y) == int:
                f_salida.write("    imull $" + self.y + ", %eax\n")
                f_salida.write("    divl %ecx\n")
                f_salida.write("    movl %ecx, %eax\n")
            else:   #Si y fuera una global
                f_salida.write("    imull " + self.y + "%eax\n")
                f_salida.write("    divl %ecx\n")
                f_salida.write("    movl %ecx, %eax\n")
        eax = True

    def escribirDivi3(self):#LLamaremos a esta función cuando el segundo es entero
        if eax == True: #Si el registro %eax contiene algo, lo pasamos a %ebx
            f_salida.write("    movl %eax, %ebx")
        if self.x in tablaVarLocal:
            f_salida.write("    movl " + tablaVarLocal[self.x] + "(%ebp), %eax\n")
            f_salida.write("    cdq\n")
        else:
            if type(self.x) == int:
                f_salida.write("    movl $" + self.x + "(%ebp), %eax\n")
                f_salida.write("    cdq\n")
            else:
                f_salida.write("    movl " + self.x +"(%ebp), %eax\n")
                f_salida.write("    cdq\n")

        f_salida.write("    imull $" + self.y + ", %eax\n")
        f_salida.write("    divl %ecx\n")
        f_salida.write("    movl %ecx, %eax\n")
        eax = True
        


class PracParser(Parser):
    tokens = PracLexer().tokens
    
    def __init__(self):
        self.names = { }
        
    @_('instruccion entrada')
    def entrada(self,p):
        pass

    @_(' ')
    def entrada(self, p):
        print(" ")
        

    ######### instruccion ########
    @_('funcion')
    def instruccion(self,p):
        pass
    
    @_('inicializacion ";"')
    def instruccion(self,p):
        pass

    @_('asignacion ";"')
    def instruccion(self,p):
        pass
        
        
    ######## contenido #####

    @_('asignacion ";" contenido')
    def contenido(self,p):
        pass

    @_('inicializacion ";" contenido')
    def contenido(self,p):
        pass

    @_('condicional contenido')
    def contenido(self,p):
        pass

    @_('retorno ";" contenido')
    def contenido(self,p):
        pass

    @_(' ')
    def contenido(self,p):
        pass

    ######## funcion #######
    @_('TIPO ID empty1 "(" inicializacion_cabecera ")" "{" contenido "}"')
    def funcion(self,p):
        nodo = NodoInic()
        nodo.escribirFinal()

    @_(' ') #Necesario para escribir el inicio de una función antes de que se escriba el resto de esta
    def empty1(self,p):
        global inFunction
        inFunction = True
        nodo = NodoFuncion(p[-1])
        nodo.escribirPrincipio()
        nodo = NodoInic()
        nodo.escribirPrologo()
        
    
    ######### inicializacion ########
    @_('TIPO ID resto')
    def inicializacion(self,p):
        global inFunction, pila
        pila -= 4
        nodo = NodoVariables(p.ID,pila)
        nodo.escribirInic()
        nodo.almacenarVariable()
        
    @_('TIPO ID asignacion resto')
    def inicializacion(self,p):
        global inFunction, pila
        if inFunction == True:
            nodo = NodoVariables(p.ID,pila)
            nodo.almacenarGlobal()
        else:
            pila -= 4
            nodo = NodoVariables(p.ID,pila)
            nodo.escribirInic()
            nodo.almacenarVariable()
    
    @_('"," ID resto')
    def resto(self,p):
        global inFunction, pila
        if inFunction == True:
            nodo = NodoVariables(p.ID,pila)
            nodo.almacenarGlobal()
        else:
            pila -= 4
            nodo = NodoVariables(p.ID,pila)
            nodo.escribirInic()
            nodo.almacenarVariable()
    
    @_('"," ID asignacion resto')
    def resto(self,p):
        pass    

    @_(' ')
    def resto(self,p):
        pass

    ######### inicializacion_cabecera ########
    @_('TIPO ID resto_cabecera')
    def inicializacion_cabecera(self,p):
        global cabecera
        cabecera += 4
        nodo = NodoVariables(p.ID,cabecera)
        nodo.almacenarVariable()

    @_(' ')
    def inicializacion_cabecera(self,p):
        pass
    
    @_('"," TIPO ID resto_cabecera')
    def resto_cabecera(self,p):
        global cabecera
        cabecera += 4
        nodo = NodoVariables(p.ID,cabecera)
        nodo.almacenarVariable()

    @_(' ')
    def resto_cabecera(self,p):
        global cabecera
        cabecera = 4
 
    ######### condicional ########
    @_('IF "(" operacionLog ")" "{" contenido "}"')
    def condicional(self,p):
        pass

    @_('IF "(" operacionLog ")" "{" contenido "}" ELSE "{" contenido "}"')
    def condicional(self,p):
        pass

    @_('WHILE "(" operacionLog ")" "{" contenido "}"')
    def condicional(self,p):
        pass
    
    @_('exprLog')
    def operacionLog(self,p):
        pass
    
    @_('factor AND exprLog')
    def exprLog(self,p):
        pass

    @_('factor EQ exprLog')
    def exprLog(self,p):
        pass

    @_('factor OR exprLog')
    def exprLog(self,p):
        pass

    @_('factor NOT exprLog')
    def exprLog(self,p):
        pass

    @_('factor GT exprLog')
    def exprLog(self,p):
        pass

    @_('factor LT exprLog')
    def exprLog(self,p):
        pass

    @_('factor NE exprLog')
    def exprLog(self,p):
        pass

    @_('factor GE exprLog')
    def exprLog(self,p):
        pass

    @_('factor LE exprLog')
    def exprLog(self,p):
        pass    

    @_(' ')
    def exprLog(self,p):
        pass
        
    ######### asignacion ######

    @_('ID ASSIGN operacion')
    def asignacion(self,p):
        pass #Aquí se guarda y se hace la asignacion

    @_('operacionAri')
    def operacion(self,p):
        pass

    @_('operacionLog')
    def operacion(self,p):
        pass

    ## operaciones aritmeticas##

    @_('sum')
    def operacionAri(self,p):
        pass

    @_('sum MINUS operacionAri')
    def operacionAri(self,p):
        if type(p.sum) == int:
            nodo = NodoOperacionesArit(p.sum,p.operacionAri)
            nodo.escribirResta2()
        else:
            if type(p.operacionAri) == int:
                nodo = NodoOperacionesArit(p.operacionAri,p.sum)
                nodo.escribirResta2()
            else:
                nodo = NodoOperacionesArit(p.sum,p.operacionAri)
                nodo.escribirResta1()

    @_('sum PLUS operacionAri')
    def operacionAri(self,p):
        if type(p.sum) == int:
            nodo = NodoOperacionesArit(p.sum,p.operacionAri)
            nodo.escribirSuma2()
        else:
            if type(p.operacionAri) == int:
                nodo = NodoOperacionesArit(p.operacionAri,p.sum)
                nodo.escribirSuma2()
            else:
                nodo = NodoOperacionesArit(p.sum,p.operacionAri)
                nodo.escribirSuma1()


    @_('exprAri TIMES exprAri')
    def sum(self,p):
        f_salida.write("    imull %ebx,%eax\n")


    @_('exprAri DIVIDE exprAri')
    def sum(self,p):
        pass

    @_('factor')
    def sum(self,p):
        pass

    @_('"(" exprAri ")"')
    def exprAri(self,p):
        pass

    @_('factor PLUS factor')
    def exprAri(self,p):
        if type(p.factor0) == int:
            nodo = NodoOperacionesArit(p.factor0,p.factor1)
            nodo.escribirSuma2()
        else:
            if type(p.factor1) == int:
                nodo = NodoOperacionesArit(p.factor1,p.factor0)
                nodo.escribirSuma2()
            else:
                nodo = NodoOperacionesArit(p.factor0,p.factor1)
                nodo.escribirSuma1()


    @_('factor DIVIDE factor')
    def exprAri(self,p):
        if type(p.factor0) == int:
            nodo = NodoOperacionesArit(p.factor0,p.factor1)
            nodo.escribirDivi2()
        else:
            if type(p.factor1) == int:
                nodo = NodoOperacionesArit(p.factor0,p.factor1)
                nodo.escribirDivi3()
            else:
                nodo = NodoOperacionesArit(p.factor0,p.factor1)
                nodo.escribirDivi1()

    @_('factor TIMES factor')
    def exprAri(self,p):
        if type(p.factor0) == int:
            nodo = NodoOperacionesArit(p.factor0,p.factor1)
            nodo.escribirMulti2()
        else:
            if type(p.factor1) == int:
                nodo = NodoOperacionesArit(p.factor1,p.factor0)
                nodo.escribirMulti2()
            else:
                nodo = NodoOperacionesArit(p.factor0,p.factor1)
                nodo.escribirMulti1()

    @_('factor MINUS factor')
    def exprAri(self,p):
        if type(p.factor0) == int:
            nodo = NodoOperacionesArit(p.factor0,p.factor1)
            nodo.escribirResta2()
        else:
            if type(p.factor1) == int:
                nodo = NodoOperacionesArit(p.factor1,p.factor0)
                nodo.escribirResta2()
            else:
                nodo = NodoOperacionesArit(p.factor0,p.factor1)
                nodo.escribirResta1()

    
    @_('factor')
    def exprAri(self,p):
        pass

    @_('MINUS NUMBER')
    def factor(self,p):
        return -p.NUMBER

    @_('NUMBER')
    def factor(self,p):
        return p.NUMBER

    @_('ID')
    def factor(self,p):
        return p.ID

    
    ######### retorno ########
    @_('RETURN devuelve')
    def retorno(self,p):
        pass
    
    @_('operacion')
    def devuelve(self,p):
        pass

    @_(' ')
    def devuelve(self,p):
        pass

    @_('INT')
    def TIPO(self,p):
        pass
 
    
  
if __name__ == '__main__':
    lexer = PracLexer()
    parser = PracParser()
    
    f_entrada = open('assembler.c','r')
    f_salida = open('main.s','w')
    option = 'assembler.c'
    with open(option, 'r') as code:
            text =  code.read()
            file = open('salida.s','w')
    try:
        if text:
            parser.parse(lexer.tokenize(text))
            file.write('###Fin del programa###')
            file.close()

    except KeyboardInterrupt:
        print('Fin del programa')